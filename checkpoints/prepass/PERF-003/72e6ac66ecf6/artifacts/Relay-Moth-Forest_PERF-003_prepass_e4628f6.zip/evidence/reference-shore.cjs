'use strict';
// Transcribed verbatim function bodies from surfacefx.js at
// e4628f63fee57b7e4ccd32aff4bc331d7d06605b, blob a74d6636a3f692082cbe12fac88d76ea8dc6a76c.
// This is an excerpt module, NOT a byte-identical copy of the complete source file.
  const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
  function fieldResolutionForQuality(quality,logicalW=640,logicalH=360){
    const q=clamp(Math.round(Number(quality)||0),0,4);
    if(q<=0)return[0,0];
    const base=q===1?128:q===2?224:q===3?320:416;
    return[base,Math.max(2,Math.round(base*logicalH/logicalW))];
  }
  function buildShoreField(mask,w,h,maxDistance=18){
    const n=w*h,dist=new Float32Array(n),inf=1e6,diag=1.41421356;
    for(let i=0;i<n;i++)dist[i]=mask[i]?inf:0;
    for(let y=0;y<h;y++)for(let x=0;x<w;x++){
      const i=y*w+x;if(!mask[i])continue;let d=dist[i];
      if(x>0)d=Math.min(d,dist[i-1]+1);
      if(y>0)d=Math.min(d,dist[i-w]+1);
      if(x>0&&y>0)d=Math.min(d,dist[i-w-1]+diag);
      if(x+1<w&&y>0)d=Math.min(d,dist[i-w+1]+diag);
      dist[i]=d;
    }
    for(let y=h-1;y>=0;y--)for(let x=w-1;x>=0;x--){
      const i=y*w+x;if(!mask[i])continue;let d=dist[i];
      if(x+1<w)d=Math.min(d,dist[i+1]+1);
      if(y+1<h)d=Math.min(d,dist[i+w]+1);
      if(x+1<w&&y+1<h)d=Math.min(d,dist[i+w+1]+diag);
      if(x>0&&y+1<h)d=Math.min(d,dist[i+w-1]+diag);
      dist[i]=d;
    }
    const rgba=new Uint8Array(n*4),md=Math.max(1,maxDistance);
    for(let i=0;i<n;i++){
      const wet=!!mask[i],d=wet?clamp(dist[i],0,md):0,o=i*4;
      rgba[o]=wet?255:0;
      rgba[o+1]=wet?Math.round(d/md*255):0;
      rgba[o+2]=wet?Math.round(clamp(1-d/md,0,1)*255):0;
      rgba[o+3]=255;
    }
    return{rgba,dist,maxDistance:md};
  }
module.exports={buildShoreField,fieldResolutionForQuality};
