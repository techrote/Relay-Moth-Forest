'use strict';
const assert=require('node:assert/strict'),fs=require('node:fs'),path=require('node:path'),crypto=require('node:crypto');
const root=path.resolve(__dirname,'..'),out=path.resolve(process.argv[2]||path.join(root,'results'));
fs.mkdirSync(out,{recursive:true});
const retained=require('../evidence/reference-shore.cjs');
const reference=process.env.PERF003_REFERENCE?require(path.resolve(process.env.PERF003_REFERENCE)):retained;
const {buildShoreField,fieldResolutionForQuality}=reference;
const {applyBounded,planDirty,encoded}=require('./bounded-shore.cjs');
const sha=b=>crypto.createHash('sha256').update(b).digest('hex');
function diff(a,b,w){let bytes=0,cells=0,first=null;for(let i=0;i<a.length;i+=4){let hit=false;for(let k=0;k<4;k++)if(a[i+k]!==b[i+k]){bytes++;hit=true;}if(hit){cells++;if(!first)first={x:(i/4)%w,y:Math.floor(i/4/w),expected:[...a.slice(i,i+4)],actual:[...b.slice(i,i+4)]};}}return{bytes,cells,first};}
const point=(x,y,w)=>y*w+x;
const rectEdits=(x0,y0,x1,y1,v,w)=>{const a=[];for(let y=y0;y<y1;y++)for(let x=x0;x<x1;x++)a.push([point(x,y,w),v]);return a;};
function materialize(f){
  if(f.mask)return Uint8Array.from(f.mask);
  const a=new Uint8Array(f.w*f.h).fill(f.fill??1);
  for(const r of f.rects||[])for(const [i,v] of rectEdits(...r,f.w))a[i]=v;
  return a;
}
const fixtures=[];
for(let q=1;q<=4;q++){
 const [w,h]=fieldResolutionForQuality(q),md=q===1?10:q===2?16:22,cx=Math.floor(w/2),cy=Math.floor(h/2);
 const common={w,h,md,quality:q,synthetic:true};
 fixtures.push({...common,name:`q${q}-wet-to-dry`,fill:1,edits:[[point(cx,cy,w),0]]});
 fixtures.push({...common,name:`q${q}-dry-to-wet-remove-last-shore`,fill:1,rects:[[cx,cy,cx+1,cy+1,0]],edits:[[point(cx,cy,w),1]]});
 fixtures.push({...common,name:`q${q}-replacement-shore-outside-output`,fill:1,rects:[[cx,cy,cx+1,cy+1,0],[cx+md+1,cy,cx+md+2,cy+1,0]],edits:[[point(cx,cy,w),1]]});
 fixtures.push({...common,name:`q${q}-bridge-segment`,fill:1,rects:[[0,0,cx-8,h,0],[cx+8,0,w,h,0]],edits:rectEdits(cx-8,cy,cx+8,cy+2,0,w)});
 fixtures.push({...common,name:`q${q}-mutually-interacting-removals`,fill:1,rects:[[cx-2,cy,cx-1,cy+1,0],[cx+2,cy,cx+3,cy+1,0]],edits:[[point(cx-2,cy,w),1],[point(cx+2,cy,w),1],[point(cx,cy+3,w),0]]});
 fixtures.push({...common,name:`q${q}-disjoint-edits`,fill:1,edits:[[point(3,3,w),0],[point(w-4,h-4,w),0]]});
 fixtures.push({...common,name:`q${q}-source-overlap-output-disjoint`,fill:1,edits:[[point(cx-md-3,cy,w),0],[point(cx+md+3,cy,w),0]]});
 fixtures.push({...common,name:`q${q}-all-dry-one-wet`,fill:0,edits:[[point(cx,cy,w),1]]});
 fixtures.push({...common,name:`q${q}-shore-adjacent`,fill:1,rects:[[0,0,cx,h,0]],edits:[[point(cx,cy,w),0],[point(cx-1,cy+2,w),1]]});
 for(const [tag,x,y] of [['left',0,cy],['right',w-1,cy],['top',cx,0],['bottom',cx,h-1],['corner',0,0]])fixtures.push({...common,name:`q${q}-edge-${tag}`,fill:1,edits:[[point(x,y,w),0]]});
 // Ideal center-sampled tile; Canvas acquisition is separately probed, not assumed here.
 const x0=Math.ceil(304*w/640-.5),x1=Math.ceil(320*w/640-.5),y0=Math.ceil(144*h/360-.5),y1=Math.ceil(160*h/360-.5);
 fixtures.push({...common,name:`q${q}-logical-tile-ideal-center-sampling`,fill:1,logicalRect:[304,144,320,160],edits:rectEdits(x0,y0,x1,y1,0,w)});
 fixtures.push({...common,name:`q${q}-no-net-change`,fill:1,edits:[[point(cx,cy,w),0],[point(cx,cy,w),1]]});
 fixtures.push({...common,name:`q${q}-large-edit-fallback`,fill:1,edits:rectEdits(Math.floor(w/4),Math.floor(h/4),Math.floor(3*w/4),Math.floor(3*h/4),0,w)});
 fixtures.push({...common,name:`q${q}-fragmented-fallback`,fill:1,edits:[[point(1,1,w),0],[point(w-2,h-2,w),0]],options:{maxRects:1}});
}
fixtures.push({name:'height-one',w:80,h:1,md:10,fill:1,rects:[[31,0,32,1,0],[42,0,43,1,0]],edits:[[31,1]],synthetic:true});
fixtures.push({name:'width-one',w:1,h:80,md:10,fill:1,rects:[[0,31,1,32,0],[0,42,1,43,0]],edits:[[31,1]],synthetic:true});
const rows=[];let comparisons=0,totalComparedBytes=0;
function run(f,{retain=true,options={}}={}){
  const before=materialize(f),old=buildShoreField(before,f.w,f.h,f.md),mask=before.slice(),rgba=old.rgba.slice();
  const final=before.slice();for(const [i,v]of f.edits)final[i]=v;
  const expect=buildShoreField(final,f.w,f.h,f.md);
  const stats=applyBounded(mask,rgba,f.w,f.h,f.edits,f.md,{...options,...f.options});
  assert.deepEqual(mask,final,`${f.name}: mask`);const mismatch=diff(expect.rgba,rgba,f.w);
  if(mismatch.bytes){fs.writeFileSync(path.join(out,'unexpected-failure.json'),JSON.stringify({fixture:f,mismatch,stats},null,2));throw new Error(`${f.name}: ${JSON.stringify(mismatch)}`);}
  // CPU simulation of the exact packed patches, including untouched destination bytes.
  const uploaded=old.rgba.slice();for(const u of stats.uploads){const r=u.rect,rw=r.x1-r.x0;for(let y=r.y0;y<r.y1;y++)uploaded.set(u.bytes.subarray((y-r.y0)*rw*4,(y-r.y0+1)*rw*4),(y*f.w+r.x0)*4);}
  assert.deepEqual(uploaded,expect.rgba,`${f.name}: packed upload`);
  comparisons++;totalComparedBytes+=rgba.length;
  if(retain){const row={name:f.name,quality:f.quality??null,w:f.w,h:f.h,maxDistance:f.md,mode:stats.mode,reason:stats.reason,changedMaskCells:stats.changedMaskCells,fullCells:f.w*f.h,distanceCells:stats.distanceCells,scanVisits:2*stats.distanceCells,encodedCells:stats.encodedCells,changedEncodedCells:stats.changedCells,uploadBytes:stats.uploadBytes,fullUploadBytes:4*f.w*f.h,regions:stats.regions,encodedSHA256:sha(rgba),mismatchedBytes:0};rows.push(row);fs.writeFileSync(path.join(out,`${f.name}.rgba`),rgba);}
  return stats;
}
for(const f of fixtures)run(f);
// Exhaust every binary 3x3 mask and each single toggle, for radii 1..4.
let exhaustive=0;for(let bits=0;bits<512;bits++)for(let i=0;i<9;i++)for(let md=1;md<=4;md++){
 const mask=Array.from({length:9},(_,j)=>(bits>>j)&1);run({name:`exhaust-${bits}-${i}-${md}`,w:3,h:3,md,mask,edits:[[i,1-mask[i]]]},{retain:false,options:{maxWorkRatio:Infinity}});exhaustive++;
}
// Longer sparse/dense runs, reproducible xorshift seed, mixed batches and all four md choices.
let seed=0x330003;function rng(){seed^=seed<<13;seed^=seed>>>17;seed^=seed<<5;return(seed>>>0)/4294967296;}
let random=0;
for(let t=0;t<800;t++){
 const w=32+Math.floor(rng()*100),h=1+Math.floor(rng()*72),md=[1,2,3,4,10,16,22][t%7],p=[.001,.02,.2,.5,.95,1][t%6];
 const mask=Array.from({length:w*h},()=>rng()<p?0:1),edits=[];for(let j=0,n=1+Math.floor(rng()*8);j<n;j++){const i=Math.floor(rng()*mask.length);edits.push([i,1-mask[i]]);}
 run({name:`random-${t}`,w,h,md,mask,edits},{retain:false,options:{maxWorkRatio:Infinity,maxRects:64}});random++;
}
// Sequential edits/undo-like inversions must work from the last committed cache, not initial state.
let serial=0;{const w=128,h=72,md=10,mask=new Uint8Array(w*h).fill(1),rgba=buildShoreField(mask,w,h,md).rgba;
 for(let t=0;t<180;t++){const i=Math.floor(rng()*mask.length),v=1-mask[i];applyBounded(mask,rgba,w,h,[[i,v]],md,{maxWorkRatio:Infinity});assert.deepEqual(rgba,buildShoreField(mask,w,h,md).rgba);serial++;}}
// Invalid input is rejected before any mutation.
let invalid=0;for(const bad of [[[0,0],[-1,1]],[[0,0],[2,2]],[[0,0],[NaN,1]],[[0,0],[99,1]]]){
 const mask=new Uint8Array(9).fill(1),rgba=buildShoreField(mask,3,3,2).rgba,oldMask=mask.slice(),oldRgba=rgba.slice();assert.throws(()=>applyBounded(mask,rgba,3,3,bad,2));assert.deepEqual(mask,oldMask);assert.deepEqual(rgba,oldRgba);invalid++;}
// Deliberate defect: use output region as source (omit the second halo).
function negative(f){const mask=materialize(f),old=buildShoreField(mask,f.w,f.h,f.md).rgba,actual=old.slice();applyBounded(mask,actual,f.w,f.h,f.edits,f.md,{maxWorkRatio:Infinity,omitSourceHalo:true});const expected=buildShoreField(mask,f.w,f.h,f.md).rgba;return{fixture:f,mismatch:diff(expected,actual,f.w),expected:[...expected],actual:[...actual]};}
let reduced=null,searchCount=0;
outer:for(let w=1;w<=8;w++)for(let md=1;md<=4;md++)for(let bits=0;bits<(1<<w);bits++)for(let i=0;i<w;i++){
 const mask=Array.from({length:w},(_,j)=>(bits>>j)&1);if(mask[i]!==0)continue;searchCount++;
 const n=negative({name:'minimal-single-halo-counterexample',w,h:1,md,mask,edits:[[i,1]],synthetic:true});if(n.mismatch.bytes){reduced=n;break outer;}}
assert(reduced);assert.equal(reduced.fixture.w,4);
const actualQuality=negative({name:'q1-single-halo-nearest-removal',w:12,h:1,md:10,mask:[0,...Array(10).fill(1),0],edits:[[0,1]],synthetic:true});assert(actualQuality.mismatch.bytes);
// Other representation traps are explicit counterexamples, not candidate failures.
const representations={
 complementaryBlue:{md:10,d:1,reference:encoded(1,1,10),incorrectBlue:255-encoded(1,1,10)[1]},
 fieldEdge:{mask:[1],md:2,reference:[...buildShoreField(new Uint8Array([1]),1,1,2).rgba],incorrectOutsideDry:encoded(1,1,2)},
 rawDistancesNonlocal:(()=>{const w=80,m=new Uint8Array(w).fill(1);m[0]=0;const a=buildShoreField(m,w,1,10);m[0]=1;const b=buildShoreField(m,w,1,10);return{x:79,beforeDist:a.dist[79],afterDist:b.dist[79],beforeRGBA:[...a.rgba.slice(316)],afterRGBA:[...b.rgba.slice(316)]};})(),
 nearestOnlyRelaxation:{beforeMask:[1,0,1],afterMask:[1,1,1],beforeDist:[1,0,1],expectedAfterDist:[1e6,1e6,1e6],reason:'min-only relaxation cannot increase stale distances after deletion'}
};
const summary={assessedCommit:'e4628f63fee57b7e4ccd32aff4bc331d7d06605b',node:process.version,v8:process.versions.v8,platform:process.platform,arch:process.arch,referenceSource:process.env.PERF003_REFERENCE||'retained verbatim source-function excerpt',namedCases:fixtures.length,exhaustiveSingleToggles:exhaustive,randomBatches:random,sequentialSteps:serial,invalidAtomicityChecks:invalid,completeEncodedComparisons:comparisons+serial,totalComparedBytes:totalComparedBytes+serial*128*72*4,mismatchedBytes:0,negativeControlsDetected:2,reducerSearchCount:searchCount,rows};
fs.writeFileSync(path.join(root,'fixtures','cases.json'),JSON.stringify(fixtures,null,2)+'\n');
fs.writeFileSync(path.join(out,'comparison.json'),JSON.stringify(summary,null,2)+'\n');
fs.writeFileSync(path.join(out,'counterexamples.json'),JSON.stringify({reduced,actualQuality,representations},null,2)+'\n');
const cols=['name','quality','mode','reason','fullCells','distanceCells','encodedCells','changedEncodedCells','uploadBytes','fullUploadBytes','mismatchedBytes'];fs.writeFileSync(path.join(out,'counts.csv'),cols.join(',')+'\n'+rows.map(r=>cols.map(k=>r[k]??'').join(',')).join('\n')+'\n');
console.log(JSON.stringify({...summary,rows:undefined},null,2));console.log('All positive comparisons passed; both deliberately faulty single-halo variants rejected.');
