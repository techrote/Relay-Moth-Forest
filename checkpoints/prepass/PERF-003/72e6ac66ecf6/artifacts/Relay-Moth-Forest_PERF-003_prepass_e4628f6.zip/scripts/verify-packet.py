#!/usr/bin/env python3
"""Verify all packet file bytes against SHA256SUMS; reject extras and omissions."""
import hashlib, pathlib, sys
root=pathlib.Path(sys.argv[1] if len(sys.argv)>1 else pathlib.Path(__file__).resolve().parents[1]).resolve()
records={}
for line in (root/'SHA256SUMS').read_text().splitlines():
    digest,name=line.split('  ',1)
    p=pathlib.PurePosixPath(name)
    if p.is_absolute() or '..' in p.parts or name in records: raise SystemExit('Unsafe/duplicate manifest path: '+name)
    records[name]=digest
actual={str(p.relative_to(root)).replace('\\','/') for p in root.rglob('*') if p.is_file() and p.name!='SHA256SUMS'}
if actual!=set(records): raise SystemExit(f'File set mismatch: missing={set(records)-actual}; extra={actual-set(records)}')
for name,digest in records.items():
    p=root/name
    if p.is_symlink() or hashlib.sha256(p.read_bytes()).hexdigest()!=digest: raise SystemExit('Hash mismatch: '+name)
print(f'PASS: {len(records)} file hashes and complete file set')
