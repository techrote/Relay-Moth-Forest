'use strict';
// CPU prepass prototype. No Canvas, WebGL, repository mutation or external packages.
const {buildShoreField}=require('../evidence/reference-shore.cjs');
const area=r=>(r.x1-r.x0)*(r.y1-r.y0);
const expand=(r,k,w,h)=>({x0:Math.max(0,r.x0-k),y0:Math.max(0,r.y0-k),x1:Math.min(w,r.x1+k),y1:Math.min(h,r.y1+k)});
const touches=(a,b)=>a.x0<=b.x1&&b.x0<=a.x1&&a.y0<=b.y1&&b.y0<=a.y1;
const union=(a,b)=>({x0:Math.min(a.x0,b.x0),y0:Math.min(a.y0,b.y0),x1:Math.max(a.x1,b.x1),y1:Math.max(a.y1,b.y1)});
function checkDimensions(w,h,md){
  if(!Number.isSafeInteger(w)||!Number.isSafeInteger(h)||w<1||h<1||w*h>1e6)throw new RangeError('dimensions');
  // Proof in DERIVATION.md covers these integer radii and adversarial small-radius probes.
  if(!Number.isInteger(md)||md<1||md>22)throw new RangeError('maxDistance: proof requires integer 1..22');
}
function planDirty(indices,w,h,md,options={}){
  checkDimensions(w,h,md);
  const {maxRects=8,maxWorkRatio=0.65}=options;
  if(!Number.isInteger(maxRects)||maxRects<1||maxRects>4096||!(maxWorkRatio>=0))throw new RangeError('planner options');
  const full=reason=>({mode:'full',reason,halo:md,regions:[{output:{x0:0,y0:0,x1:w,y1:h},source:{x0:0,y0:0,x1:w,y1:h}}],distanceCells:w*h,encodedCells:w*h});
  let rects=[];
  for(const i of indices){
    if(!Number.isSafeInteger(i)||i<0||i>=w*h)throw new RangeError('dirty index');
    const x=i%w,y=Math.floor(i/w);let r=expand({x0:x,y0:y,x1:x+1,y1:y+1},md,w,h);
    // Repeated restart also merges transitive overlap. Work bounded by maxRects.
    for(let j=0;j<rects.length;){if(touches(rects[j],r)){r=union(r,rects[j]);rects.splice(j,1);j=0;}else j++;}
    rects.push(r);if(rects.length>maxRects)return full('fragmentation');
  }
  rects.sort((a,b)=>a.y0-b.y0||a.x0-b.x0);
  const regions=rects.map(output=>({output,source:expand(output,md,w,h)}));
  const distanceCells=regions.reduce((n,r)=>n+area(r.source),0),encodedCells=rects.reduce((n,r)=>n+area(r),0);
  if(distanceCells>maxWorkRatio*w*h)return full('source-work-budget');
  return{mode:indices.length?'bounded':'noop',reason:null,halo:md,regions,distanceCells,encodedCells};
}
function cropMask(mask,w,r){
  const cw=r.x1-r.x0,ch=r.y1-r.y0,out=new Uint8Array(cw*ch);
  for(let y=0;y<ch;y++)out.set(mask.subarray((r.y0+y)*w+r.x0,(r.y0+y)*w+r.x1),y*cw);
  return out;
}
function distanceOnly(mask,w,h){
  // Operation order, diag literal and Float32 writes intentionally match the reference.
  const n=w*h,dist=new Float32Array(n),inf=1e6,diag=1.41421356;
  for(let i=0;i<n;i++)dist[i]=mask[i]?inf:0;
  for(let y=0;y<h;y++)for(let x=0;x<w;x++){
    const i=y*w+x;if(!mask[i])continue;let d=dist[i];
    if(x>0)d=Math.min(d,dist[i-1]+1);
    if(y>0)d=Math.min(d,dist[i-w]+1);
    if(x>0&&y>0)d=Math.min(d,dist[i-w-1]+diag);
    if(x+1<w&&y>0)d=Math.min(d,dist[i-w+1]+diag);
    dist[i]=d;
  }
  for(let y=h-1;y>=0;y--)for(let x=w-1;x>=0;x--){
    const i=y*w+x;if(!mask[i])continue;let d=dist[i];
    if(x+1<w)d=Math.min(d,dist[i+1]+1);
    if(y+1<h)d=Math.min(d,dist[i+w]+1);
    if(x+1<w&&y+1<h)d=Math.min(d,dist[i+w+1]+diag);
    if(x>0&&y+1<h)d=Math.min(d,dist[i+w-1]+diag);
    dist[i]=d;
  }
  return dist;
}
function encoded(wet,d,md){
  d=wet?Math.max(0,Math.min(md,d)):0;
  return[wet?255:0,wet?Math.round(d/md*255):0,wet?Math.round(Math.max(0,Math.min(1,1-d/md))*255):0,255];
}
function recompute(mask,rgba,w,h,md,plan,{omitSourceHalo=false}={}){
  let changedCells=0;const uploads=[];
  for(const r of plan.regions){
    const s=omitSourceHalo?r.output:r.source,a=r.output,sw=s.x1-s.x0,sh=s.y1-s.y0;
    const local=cropMask(mask,w,s),dist=distanceOnly(local,sw,sh);
    let dirty=null;
    for(let y=a.y0;y<a.y1;y++)for(let x=a.x0;x<a.x1;x++){
      const i=y*w+x,li=(y-s.y0)*sw+x-s.x0,b=encoded(mask[i],dist[li],md),o=i*4;
      let different=false;for(let k=0;k<4;k++)if(rgba[o+k]!==b[k])different=true;
      if(different){changedCells++;dirty=dirty?union(dirty,{x0:x,y0:y,x1:x+1,y1:y+1}):{x0:x,y0:y,x1:x+1,y1:y+1};rgba.set(b,o);}
    }
    // Bounded bounding-box upload; unchanged texels inside it retain their correct bytes.
    if(dirty){const aw=dirty.x1-dirty.x0,packed=new Uint8Array(area(dirty)*4);
      for(let y=dirty.y0;y<dirty.y1;y++)packed.set(rgba.subarray((y*w+dirty.x0)*4,(y*w+dirty.x1)*4),(y-dirty.y0)*aw*4);
      uploads.push({rect:dirty,bytes:packed});
    }
  }
  return{changedCells,uploads,uploadBytes:uploads.reduce((n,u)=>n+u.bytes.length,0)};
}
function applyBounded(mask,rgba,w,h,edits,md,options={}){
  checkDimensions(w,h,md);
  if(!(mask instanceof Uint8Array)||mask.length!==w*h||!(rgba instanceof Uint8Array)||rgba.length!==4*w*h)throw new TypeError('cache buffers');
  if(!Array.isArray(edits)||edits.length>4*w*h)throw new RangeError('edits must be a bounded batch');
  const final=new Map();
  for(const e of edits){if(!Array.isArray(e)||e.length!==2||!Number.isSafeInteger(e[0])||e[0]<0||e[0]>=w*h||(e[1]!==0&&e[1]!==1))throw new RangeError('edit [index, 0|1]');final.set(e[0],e[1]);}
  const changes=[...final].filter(([i,v])=>mask[i]!==v).sort((a,b)=>a[0]-b[0]);
  // Plan before mutating; validation failure must leave the cache unchanged.
  const plan=planDirty(changes.map(e=>e[0]),w,h,md,options);
  for(const [i,v] of changes)mask[i]=v;
  if(plan.mode==='full'){
    const fresh=buildShoreField(mask,w,h,md);let changedCells=0;
    for(let i=0;i<w*h;i++)if(rgba.subarray(i*4,i*4+4).some((v,k)=>v!==fresh.rgba[i*4+k]))changedCells++;
    rgba.set(fresh.rgba);
    return{...plan,changedMaskCells:changes.length,changedCells,uploads:[{rect:plan.regions[0].output,bytes:fresh.rgba}],uploadBytes:4*w*h};
  }
  return{...plan,changedMaskCells:changes.length,...recompute(mask,rgba,w,h,md,plan,options)};
}
module.exports={area,expand,planDirty,cropMask,distanceOnly,encoded,recompute,applyBounded};
