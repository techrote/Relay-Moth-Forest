#!/usr/bin/env python3
"""Finite CPU-only Chromium Canvas2D probe. No WebGL or network required."""
import argparse, html, json, os, pathlib, re, shutil, signal, subprocess, tempfile
p=argparse.ArgumentParser();p.add_argument('--chromium',default=shutil.which('chromium'));p.add_argument('--out',default=str(pathlib.Path(__file__).resolve().parents[1]/'results/canvas-acquisition.json'));a=p.parse_args()
if not a.chromium: raise SystemExit('Chromium required for this separate optional acquisition probe')
result={}
with tempfile.TemporaryDirectory(prefix='perf003-canvas-') as tmp:
    args=[a.chromium,'--headless','--no-sandbox','--disable-gpu','--disable-software-rasterizer','--disable-background-networking','--disable-extensions','--no-first-run','--user-data-dir='+tmp,'--dump-dom',pathlib.Path(__file__).with_name('canvas-probe.html').resolve().as_uri()]
    proc=subprocess.Popen(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,start_new_session=True)
    try:
        stdout,stderr=proc.communicate(timeout=35)
        m=re.search(r'<pre id="result">(.*?)</pre>',stdout,re.S)
        if not m: result={'pass':False,'status':'NO_RESULT','stderrTail':stderr[-2000:]}
        else: result=json.loads(html.unescape(m.group(1)))
        result['exitCode']=proc.returncode
    except subprocess.TimeoutExpired:
        os.killpg(proc.pid,signal.SIGKILL);proc.communicate(timeout=5)
        result={'pass':None,'status':'TIMEOUT','timeoutSeconds':35,'exitCode':proc.returncode}
    result['command']=[x if not x.startswith('--user-data-dir=') else '--user-data-dir=<temporary>' for x in args[:-1]]+['file://<packet>/scripts/canvas-probe.html']
    pathlib.Path(a.out).parent.mkdir(parents=True,exist_ok=True);pathlib.Path(a.out).write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2));raise SystemExit(0 if result.get('pass') is True and result.get('exitCode')==0 else 1)
