'use strict';
// Supply the actual complete file from the pinned repository checkout; do not
// confuse the retained function excerpt with a full downloaded Git blob.
const fs=require('node:fs'),crypto=require('node:crypto'),path=require('node:path'),assert=require('node:assert/strict');
if(process.argv.length!==3)throw new Error('usage: node scripts/verify-reference.cjs /absolute/path/to/surfacefx.js');
const p=path.resolve(process.argv[2]),bytes=fs.readFileSync(p),sha=crypto.createHash('sha256').update(bytes).digest('hex');
assert.equal(sha,'584e4c9f834ff3d9ed7f191bb942325c713ec3f7047ea307ff122d0e727670d1','complete surfacefx.js does not match assessed source');
const full=require(p),excerpt=require('../evidence/reference-shore.cjs'),compact=f=>f.toString().replace(/\s+/g,'');
for(const name of ['buildShoreField','fieldResolutionForQuality'])assert.equal(compact(full[name]),compact(excerpt[name]),`${name} excerpt differs from full source`);
console.log(JSON.stringify({pass:true,assessedCommit:'e4628f63fee57b7e4ccd32aff4bc331d7d06605b',fullFileSHA256:sha,verifiedFunctions:['buildShoreField','fieldResolutionForQuality']},null,2));
