# HANDOFF — Relay-Moth-Forest PERF-003 / #33

Assessed main: **e4628f63fee57b7e4ccd32aff4bc331d7d06605b** (PERF-002 / #34 merged). No remote writes, comments or workflow actions.

**Algorithm settled:** retain mask/RGBA; H=M=10/16/22/22 field samples. Candidate outputs are net dirty samples expanded H; source crops are outputs expanded a further H. Run the existing Float32 recurrence in each source crop and encode only outputs. Clip to the real field; no invented dry boundary. Apply all edits to final mask before any crop. Keep deterministic full fallback.

**Evidence:** 19,486 complete-field comparisons / 30,969,024 bytes / zero differences, plus four invalid-input checks. Two one-halo defect controls fail; reduced counterexample is four cells. See `results/comparison.json`, `counts.csv`, `counterexamples.json` and replay commands in README.

**Representation warnings:** raw distances are not locally maintainable under this encoding bound; blue is separately rounded, not 255-green; do not reconstruct distances from encoded bytes. Source functions are retained excerpts, not a full repository clone. The supplied verifier binds them to a separately available complete pinned `surfacefx.js`.

**Intended repository paths:** production integration in `surfacefx.js` (cache, bounded CPU seam, upload, telemetry) and `game.js` (effective authority delta and legacy/shore coherent commit), editor lifecycle in `editor.js`; tests under `tests/current/perf003_prepass/`, later integration regressions beside `tests/current/surfacefx_regression.js` and `editor_invalidation_regression_415.js`; evidence under `docs/validation/performance/PERF-003-prepass.md`. The included additive patch installs only prepass tests/docs.

**Remaining gates:** browser Canvas mask acquisition/crop parity (two local attempts timed out); typed-array upload orientation/pixel-store/context recovery; both legacy and shore textures; real bridge final-phase authority and editor pointerup/cancel/undo/save integration; split PERF-001A before/after measurements and all inherited pixel/shader regressions. No browser/GPU or hardware timing acceptance is claimed. Thresholds of eight rectangles / 65% summed source area are initial resource policy, not tuned results.

Start with telemetry, verify the oracle against the full source, establish mask acquisition parity, then wire transaction bookkeeping and subimages. `INTEGRATION.md` specifies exact existing call boundaries and failure rules.
