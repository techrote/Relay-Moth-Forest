# PERF-003 algorithm prepass packet

**Decision:** bounded recomputation is sound for the existing RGBA encoding. Use H=M (10/16/22/22 quality samples), expand dirty pixels by H for candidate outputs, and expand those outputs by H again for source acquisition by the distance transform. Rebuild from final mask data, never stale distance boundaries. Preserve the full fallback.

Assessed commit: `e4628f63fee57b7e4ccd32aff4bc331d7d06605b` in `techrote/Relay-Moth-Forest`. GitHub was read-only throughout.

## Read and reproduce

`DERIVATION.md` contains the recurrence-level proof, source/output distinction, representation traps and counterexample. `INTEGRATION.md` contains proposed interfaces, bridge/editor transaction mapping, fallback policy, telemetry and implementation order. `HANDOFF.md` is the short worker handoff. `evidence/SOURCES.md` distinguishes original source identities from retained excerpts and newly generated evidence.

No npm install or external package is needed:

```sh
python3 scripts/verify-packet.py .
node scripts/compare.cjs /tmp/perf003-replay
```

The comparator recreates `fixtures/cases.json` deterministically and writes complete fields, counts and comparison results to the selected output directory. The JSON fixture uses row-major indices, wet=1 / dry=0, half-open rectangles, with full materialization in the comparator. Each `.rgba` file is row-major top-down RGBA8 at the dimensions in `results/comparison.json`.

To bind the oracle directly to a separately available full pinned checkout:

```sh
node scripts/verify-reference.cjs /path/to/Relay-Moth-Forest/surfacefx.js
PERF003_REFERENCE=/path/to/Relay-Moth-Forest/surfacefx.js \
  node scripts/compare.cjs /tmp/perf003-full-source-replay
```

An optional separate browser acquisition probe is supplied:

```sh
python3 scripts/run-canvas-probe.py --out /tmp/perf003-canvas.json
```

That probe did not complete here. Its lack of results is not folded into the passing CPU algorithm result. No WebGL acceptance, target hardware test, new PERF-001A timing or real Tin Stream capture was performed.

## Results

19,486 complete encoded-field comparisons passed, with 30,969,024 bytes compared and zero differences. Four additional malformed-input tests preserve cache state. Both intentional one-halo variants failed as expected; the smallest retained counterexample has four cells. The per-quality bridge is explicitly synthetic. Source-rectangle work, encoded output work, changed bytes and packed-upload sizes are separate in `results/counts.csv`.

The additive `proposed/perf003-prepass-tests.patch` is for a prepass test subtree and documentation only. It does not modify active runtime files or install the proposed WebGL integration. Its local application/replay check is described in `results/package-checks.json`.

The ZIP's SHA-256 is provided separately. `SHA256SUMS` covers every packet file except itself; `scripts/verify-packet.py` rejects missing, additional or changed files (ignoring no files). Verification does not claim the external GitHub repository has been modified or that a checkpoint was published there.
